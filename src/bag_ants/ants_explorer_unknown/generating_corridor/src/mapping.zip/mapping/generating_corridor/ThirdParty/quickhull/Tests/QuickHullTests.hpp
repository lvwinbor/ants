#ifndef QuickHullTests_h
#define QuickHullTests_h

namespace quickhull {
	
	namespace tests {
		
		void run();
		
	}
	
}

#endif /* QuickHullTests_h */
