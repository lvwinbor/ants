#ifndef CORRIDOR_BUILDER_H
#define CORRIDOR_BUILDER_H

#include <cmath>

#include <Eigen/Dense>
#include <Eigen/Core>

#include <pcl/point_types.h>
#include <pcl/point_cloud.h>
#include <pcl/common/transforms.h>
#include <pcl/surface/convex_hull.h>

namespace FastLab {

    struct Triangle {
        Triangle(){};
        Triangle(pcl::PointXYZ a, pcl::PointXYZ b, pcl::PointXYZ c): _a(a), _b(b), _c(c){};
        pcl::PointXYZ _a;
        pcl::PointXYZ _b;
        pcl::PointXYZ _c;
        Eigen::Vector3d _normal;
        
        void calcuNormal() { //Point to origin
            float x1 = _a.x - _c.x;
            float y1 = _a.y - _c.y;
            float z1 = _a.z - _c.z;
            float x2 = _b.x - _c.x;
            float y2 = _b.y - _c.y;
            float z2 = _b.z - _c.z;
            _normal[0] = y1*z2 - z1*y2;
            _normal[1] = z1*x2 - x1*z2;
            _normal[2] = x1*y2 - y1*x2;
            _normal.normalize();
            float dot_product = -_c.x*_normal[0] - _c.y*_normal[1] - _c.z*_normal[2];
            if (dot_product<0) _normal = - _normal;
        }

    };

    struct Plane {
        Plane() {}
        Plane(pcl::PointXYZ p, Eigen::Vector3d& normal): _p(p), _normal(normal){};
        
        pcl::PointXYZ _p;
        Eigen::Vector3d _normal;
    };

    class Corridor {
    public:
        Corridor(pcl::PointCloud<pcl::PointXYZ>::Ptr data);
        ~Corridor() {};
        void build(const pcl::PointXYZ origin, std::vector<Triangle>& meshes);

    private:
        pcl::PointCloud<pcl::PointXYZ>::Ptr _data_ptr;

        pcl::PointXYZ flipMap(pcl::PointXYZ input);
        pcl::PointXYZ inverseMap(pcl::PointXYZ input);
        double distanceP2P(Eigen::Vector3d& normal, pcl::PointXYZ p_on_plane, pcl::PointXYZ p_query); // respect to P2P
        
        // judge whether the input point is in convexhull, get the normal vector of the nearest triangle. 
        // return the index of nearest triangle in convexhull. return -1 means that the point is outside. 
        int isInsideHull(std::vector<Triangle>& convexhull, pcl::PointXYZ p, float& min_d);
        
        void H2V(std::vector<Plane>& planes, std::vector<pcl::PointXYZ>& vertices);
        void V2H(std::vector<pcl::PointXYZ>& vertices);

    };



}


#endif //CORRIDOR_BUILDER_H