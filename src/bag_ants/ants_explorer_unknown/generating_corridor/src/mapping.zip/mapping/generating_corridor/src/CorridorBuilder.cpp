#include <assert.h>
#include <ctime>
#include <cmath>

#include <pcl/common/common.h>
#include <pcl/io/pcd_io.h>

#include <setoper.h>
#include <cdd.h>

#include "CorridorBuilder.h"
#include "quickhull/QuickHull.hpp"
#include "tic_toc.h"

const float r = 5;

namespace FastLab {

   Corridor::Corridor(pcl::PointCloud<pcl::PointXYZ>::Ptr data) {
       _data_ptr = data;
   }

//    pcl::PointXYZ Corridor::flipMap(pcl::PointXYZ input) { // stereographic projection
//        pcl::PointXYZ p;
//        float norm2 = input.x*input.x + input.y*input.y + input.z*input.z; 
//        p.x = 2*input.x/(norm2+1);
//        p.y = 2*input.y/(norm2+1);
//        p.z = 2*input.z/(norm2+1);
//        return p;
//    }
   
//    pcl::PointXYZ Corridor::inverseMap(pcl::PointXYZ input) { // TODO: find index directly from quick hull
//        pcl::PointXYZ p;
//        float norm2 = input.x*input.x + input.y*input.y + input.z*input.z;
//        float ori_norm2 = (2-norm2+std::sqrt(norm2*norm2+4-3*norm2))/(norm2);
//        p.x = 0.5*(ori_norm2+1)*input.x;
//        p.y = 0.5*(ori_norm2+1)*input.y;
//        p.z = 0.5*(ori_norm2+1)*input.z;
//        return p;
//    }

   pcl::PointXYZ Corridor::flipMap(pcl::PointXYZ input) { // sphere flipping projection
       pcl::PointXYZ p; 
       float norm2 = std::sqrt(input.x*input.x + input.y*input.y + input.z*input.z);
       p.x = input.x + 2*(r-norm2)*input.x/norm2;
       p.y = input.y + 2*(r-norm2)*input.y/norm2;
       p.z = input.z + 2*(r-norm2)*input.z/norm2;
       return p;
   }
   
   pcl::PointXYZ Corridor::inverseMap(pcl::PointXYZ input) { // TODO: find index directly from quick hull
       pcl::PointXYZ p;
       float norm2 = std::sqrt(input.x*input.x + input.y*input.y + input.z*input.z);
       
       float d = 2*r - norm2;
       p.x = input.x * d/norm2;
       p.y = input.y * d/norm2;
       p.z = input.z * d/norm2;
       return p;
   }

   double Corridor::distanceP2P(Eigen::Vector3d& normal, pcl::PointXYZ p_on_plane, pcl::PointXYZ p_query) {
       Eigen::Vector3d start(p_on_plane.x, p_on_plane.y, p_on_plane.z);
       Eigen::Vector3d end(p_query.x, p_query.y, p_query.z);
       Eigen::Vector3d v = end - start;
       double distance = v.transpose()*normal;
       return distance;
   }

   int Corridor::isInsideHull(std::vector<Triangle>& convexhull, pcl::PointXYZ p, float& min_d) { // must call after calcuNormal()
       double min_distance = 1000;
       int min_index = -1;
       for (unsigned int i=0; i<convexhull.size(); i++) {
           double distance = distanceP2P(convexhull[i]._normal, convexhull[i]._c, p);
           if (distance < 0) return -1;
           if (distance < min_distance) {
               min_distance = distance;
               min_index = i; 
           }
       }
       min_d = min_distance;
       return min_index;
   }

   void Corridor::H2V(std::vector<Plane>& planes, std::vector<pcl::PointXYZ>& vertices) {
       dd_PolyhedraPtr poly;
       dd_MatrixPtr A, G;
       dd_ErrorType err;
       dd_set_global_constants();

       A=dd_CreateMatrix(planes.size(), 4);
       for (unsigned int i=0; i<planes.size(); i++) {
           double a = planes[i]._normal[0];
           double b = planes[i]._normal[1];
           double c = planes[i]._normal[2];
           double d = - (a*planes[i]._p.x + b*planes[i]._p.y + c*planes[i]._p.z);
           dd_set_d(A->matrix[i][0], d);
           dd_set_d(A->matrix[i][1], a);
           dd_set_d(A->matrix[i][2], b);
           dd_set_d(A->matrix[i][3], c);
       }
       A->representation=dd_Inequality;
       poly=dd_DDMatrix2Poly(A, &err);
       if (err!=dd_NoError) goto _L99;
       G=dd_CopyGenerators(poly);
       long i, j;
       for (i=0; i <G->rowsize; i++) {
           pcl::PointXYZ vertex(G->matrix[i][1][0], G->matrix[i][2][0], G->matrix[i][3][0]);
           vertices.push_back(vertex);
       }
       dd_FreeMatrix(A);
       dd_FreeMatrix(G);
       dd_FreePolyhedra(poly);
       _L99:
       if (err!=dd_NoError) dd_WriteErrorMessages(stdout, err);
       dd_free_global_constants();
   }

   void Corridor::V2H(std::vector<pcl::PointXYZ>& vertices) {
       dd_PolyhedraPtr poly;
       dd_MatrixPtr A, B, G;
       dd_ErrorType err;

       dd_set_global_constants();

       dd_rowrange m = vertices.size();
       dd_colrange d = 4;
       A=dd_CreateMatrix(m,d);
       for (unsigned int i=0; i<vertices.size(); i++) {
           dd_set_d(A->matrix[i][0], 1);
           dd_set_d(A->matrix[i][1], vertices[i].x);
           dd_set_d(A->matrix[i][2], vertices[i].y);
           dd_set_d(A->matrix[i][3], vertices[i].z);
        //    dd_set_d(A->matrix[i][4], vertices[i].x*vertices[i].x);
        //    dd_set_d(A->matrix[i][5], vertices[i].y*vertices[i].y);
        //    dd_set_d(A->matrix[i][6], vertices[i].z*vertices[i].z);
        //    dd_set_d(A->matrix[i][7], vertices[i].x*vertices[i].y);
        //    dd_set_d(A->matrix[i][8], vertices[i].y*vertices[i].z);
        //    dd_set_d(A->matrix[i][9], vertices[i].z*vertices[i].x);
       }
       A->representation=dd_Generator;
       poly=dd_DDMatrix2Poly(A, &err);
       if (err!=dd_NoError) goto _L99;
       G=dd_CopyInequalities(poly);
       dd_WriteMatrix(stdout,G);  printf("\n");

       dd_FreeMatrix(A);
       dd_FreeMatrix(G);
       dd_FreePolyhedra(poly);

       _L99:
       if (err!=dd_NoError) dd_WriteErrorMessages(stdout,err);

       dd_free_global_constants(); 
   }


   void Corridor::build(const pcl::PointXYZ origin, std::vector<Triangle>& meshes) {
       if (_data_ptr->empty()) return;
       for (unsigned int i = 0; i<_data_ptr->points.size(); i++) {
            _data_ptr->points[i].x -= origin.x;
            _data_ptr->points[i].y -= origin.y;
            _data_ptr->points[i].z -= origin.z;
        }
 
       std::vector<quickhull::Vector3<float> > flipcloud;
       flipcloud.reserve(_data_ptr->points.size() + 1);
       pcl::PointXYZ po = flipMap(origin);
       flipcloud.push_back(quickhull::Vector3<float>(po.x,po.y,po.z));
       for (unsigned int i=0; i<_data_ptr->points.size(); i++) {
           pcl::PointXYZ p = flipMap(_data_ptr->points[i]);
           flipcloud.push_back(quickhull::Vector3<float>(p.x,p.y,p.z));
       }

    //    pcl::io::savePCDFileBinary("/home/starry/data/1.pcd",*press_cloud);

       quickhull::QuickHull<float> qh;
       TicToc t; 
       t.tic();
       auto hull = qh.getConvexHull(flipcloud, true, false, 0.01);
       std::cout << t.toc() << "ms quick hull" << std::endl;
       
       auto vertexBuffer = hull.getVertexBuffer();
       auto indexBuffer = hull.getIndexBuffer();

       std::vector<Triangle> ori_meshes;
       for (unsigned int m=0; m<indexBuffer.size()/3; m++) {
           pcl::PointXYZ p1(vertexBuffer[indexBuffer[m*3]].x,vertexBuffer[indexBuffer[m*3]].y,vertexBuffer[indexBuffer[m*3]].z);
           pcl::PointXYZ p2(vertexBuffer[indexBuffer[m*3+1]].x,vertexBuffer[indexBuffer[m*3+1]].y,vertexBuffer[indexBuffer[m*3+1]].z);
           pcl::PointXYZ p3(vertexBuffer[indexBuffer[m*3+2]].x,vertexBuffer[indexBuffer[m*3+2]].y,vertexBuffer[indexBuffer[m*3+2]].z);
           pcl::PointXYZ op1 = inverseMap(p1);
           pcl::PointXYZ op2 = inverseMap(p2);
           pcl::PointXYZ op3 = inverseMap(p3);
        //    std::cout << "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" << p1.x << " " << p1.y << " " << p1.z<< std::endl;
           Triangle mesh(op1,op2,op3);
        //    mesh.calcuNormal();
           meshes.push_back(mesh);
       }

    //    std::vector<quickhull::Vector3<float> > ori_vertices;
    //    for (unsigned int n=0; n<vertexBuffer.size(); n++) {
    //        pcl::PointXYZ mp(vertexBuffer[n].x, vertexBuffer[n].y, vertexBuffer[n].z);
    //        pcl::PointXYZ ori_p = inverseMap(mp);
    //     //    float mpnorm = std::sqrt(ori_p.x*ori_p.x+ori_p.y*ori_p.y+ori_p.z*ori_p.z);
    //     //    float o_factor_x = ori_p.x / mpnorm;
    //     //    float o_factor_y = ori_p.y / mpnorm;
    //     //    float o_factor_z = ori_p.z / mpnorm;
    //     //    float origin_norm = (mpnorm-d)/k;

    //     //    ori_vertices.push_back(quickhull::Vector3<float>(origin_norm*o_factor_x, origin_norm*o_factor_y, origin_norm*o_factor_z));
    //        ori_vertices.push_back(quickhull::Vector3<float>(ori_p.x, ori_p.y, ori_p.z));
    //    }
       
    //    auto ori_hull = qh.getConvexHull(ori_vertices, true, false, 0.001);
    //    auto ori_vertexBuffer = ori_hull.getVertexBuffer();
    //    auto ori_indexBuffer = ori_hull.getIndexBuffer();

    //    std::vector<Triangle> ori_meshes;
    //    for (unsigned int m=0; m<ori_indexBuffer.size()/3; m++) {
    //        pcl::PointXYZ p1(ori_vertexBuffer[ori_indexBuffer[m*3]].x,ori_vertexBuffer[ori_indexBuffer[m*3]].y,ori_vertexBuffer[ori_indexBuffer[m*3]].z);
    //        pcl::PointXYZ p2(ori_vertexBuffer[ori_indexBuffer[m*3+1]].x,ori_vertexBuffer[ori_indexBuffer[m*3+1]].y,ori_vertexBuffer[ori_indexBuffer[m*3+1]].z);
    //        pcl::PointXYZ p3(ori_vertexBuffer[ori_indexBuffer[m*3+2]].x,ori_vertexBuffer[ori_indexBuffer[m*3+2]].y,ori_vertexBuffer[ori_indexBuffer[m*3+2]].z);
    //        Triangle mesh(p1,p2,p3);
    //        mesh.calcuNormal();
    //        ori_meshes.push_back(mesh);
    //    }
       
    //    float max_x = -100000; float min_x = 100000;
    //    float max_y = -100000; float min_y = 100000;
    //    float max_z = -100000; float min_z = 100000;
    //    for (auto& v: ori_vertexBuffer) {
    //        max_x = v.x > max_x ? v.x : max_x;
    //        min_x = v.x < min_x ? v.x : min_x;
    //        max_y = v.y > max_y ? v.y : max_y;
    //        min_y = v.y < min_y ? v.y : min_y;
    //        max_z = v.z > max_z ? v.z : max_z;
    //        min_z = v.z < min_z ? v.z : min_z;
    //    }

    //    std::vector<float> distances(ori_meshes.size(),-1);
    //    std::vector<Plane> planes(ori_meshes.size());

    //    for (unsigned int i=0; i<_data_ptr->points.size(); i++) {
    //        pcl::PointXYZ ap = _data_ptr->points[i];
    //        if (ap.x > max_x || ap.x < min_x || ap.y > max_y || ap.y < min_y || ap.z > max_z || ap.z < min_z) continue;
    //        float min_distance;
    //        int interior_idx = isInsideHull(ori_meshes, ap, min_distance);
    //        if (interior_idx > 0) {
    //            if (min_distance > distances[interior_idx]) {
    //                 distances[interior_idx] = min_distance;
    //                 planes[interior_idx]._p = ap;
    //                 planes[interior_idx]._normal = ori_meshes[interior_idx]._normal;
    //            }
    //        }
    //    }

    //    std::vector<Plane> constraints;
    //    for (unsigned int j=0; j<distances.size(); j++) {
    //        if (distances[j] > 0) {
    //            constraints.push_back(planes[j]);
    //        }else {
    //            constraints.push_back(Plane(ori_meshes[j]._c, ori_meshes[j]._normal));
    //        }
    //    }

    //    std::vector<pcl::PointXYZ> final_vertices;
    //    TicToc t2; 
    //    t2.tic();
    //    H2V(constraints, final_vertices);
    //    std::cout << t2.toc() << "ms cddlib" << std::endl;

    //    // ugly method, just for visualization
    //    std::vector<quickhull::Vector3<float> > q_ori_vertices;
    //    for (auto& vert: final_vertices) {
    //        q_ori_vertices.push_back(quickhull::Vector3<float>(vert.x, vert.y, vert.z));
    //    }
    //    auto final_hull = qh.getConvexHull(q_ori_vertices, true, false, 0.01);
    //    auto final_vertexBuffer = final_hull.getVertexBuffer();
    //    auto final_indexBuffer = final_hull.getIndexBuffer();

    //    for (unsigned int m=0; m<final_indexBuffer.size()/3; m++) {
    //        pcl::PointXYZ p1(final_vertexBuffer[final_indexBuffer[m*3]].x,final_vertexBuffer[final_indexBuffer[m*3]].y,final_vertexBuffer[final_indexBuffer[m*3]].z);
    //        pcl::PointXYZ p2(final_vertexBuffer[final_indexBuffer[m*3+1]].x,final_vertexBuffer[final_indexBuffer[m*3+1]].y,final_vertexBuffer[final_indexBuffer[m*3+1]].z);
    //        pcl::PointXYZ p3(final_vertexBuffer[final_indexBuffer[m*3+2]].x,final_vertexBuffer[final_indexBuffer[m*3+2]].y,final_vertexBuffer[final_indexBuffer[m*3+2]].z);
    //        Triangle mesh(p1,p2,p3);
    //        meshes.push_back(mesh);
    //    }
   }




}